import { Component, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http"
import { HttpErrorResponse } from "@angular/common/http"
import { AuthenticationService } from '../service/authentication.service';

declare var $: any;

var generateSubLink = "";
var generateLink = "";

@Component({
  selector: "app-viewts",
  templateUrl: "./viewts.component.html",
  styleUrls: ["./viewts.component.css"]
})

export class ViewtsComponent implements OnInit {

  constructor(private httpService: HttpClient, private loginService:AuthenticationService) {//private api: ApiService
  }

  weekDays: any[];
  months: string[];
  ngOnInit(): void {

    this.months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec"
    ];

    let date: Date = new Date();
    this.weekDays = [
      { day: 1, name: "Mon", date: (date.getDate() - date.getDay() + 1) + "-" + this.months[date.getMonth()] + "-" + date.getFullYear() },
      { day: 2, name: "Tue", date: (date.getDate() - date.getDay() + 2) + "-" + this.months[date.getMonth()] + "-" + date.getFullYear() },
      { day: 3, name: "Wed", date: (date.getDate() - date.getDay() + 3) + "-" + this.months[date.getMonth()] + "-" + date.getFullYear() },
      { day: 4, name: "Thu", date: (date.getDate() - date.getDay() + 4) + "-" + this.months[date.getMonth()] + "-" + date.getFullYear() },
      { day: 5, name: "Fri", date: (date.getDate() - date.getDay() + 5) + "-" + this.months[date.getMonth()] + "-" + date.getFullYear() },
      { day: 6, name: "Sat", date: (date.getDate() - date.getDay() + 6) + "-" + this.months[date.getMonth()] + "-" + date.getFullYear() },
      { day: 7, name: "Sun", date: (date.getDate() - date.getDay() + 7) + "-" + this.months[date.getMonth()] + "-" + date.getFullYear() }
    ];

    this.addProject();

    this.httpService.get("../../assets/data/EmployeeRecords.json").subscribe(
      data => {
        // this.loadData = data as any[];
        var count = 1;
        var strData = '';
        $.each(data, function (key, value) {
          if (count == 24) {
            strData += '<option selected value="' + key + '">' + key + ': ' + value + '</option>';
          } else {
            strData += '<option value="' + key + '">' + key + ': ' + value + '</option>';
          }
          count++;
        });
        $("#employee").append(strData);
      },
      (err: HttpErrorResponse) => {
        $("#reportsOf").html(
          '<div class="alert alert-danger"><strong>No data!</strong> No matched data found for this given values... </div>'
        );
      }
    );
    // this.addProject();
    // this.addNonWorkingSection();
  }

  loadData: any[];
  loadList() {
    this.loadData = null;
    this.dataDetails = null;
    this.totalProjectHrs = [];

    $("#weekly_reports").html("");
    var generateLink = "../../assets/data";
    if ($("#employee").val() == 0) {
      $.notify("Select an Employee");
      $("#employee").focus();
      return;
    }

    generateLink += "/" + $("#employee option:selected").val();
    var str =
      "Report of <strong>" +
      $("#employee option:selected").html() +
      "</strong>";
    $("#reportsOf").html(str);

    if ($("#session").val() == 0) {
      $.notify("Select a Session");
      $("#session").focus();
      return;
    }
    generateLink += "/" + $("#session option:selected").html() + "/weeks.json";
    str += " for the year of " + $("#session option:selected").html();

    generateSubLink = generateLink.substring(0, generateLink.length - 10);

    $("#reportsOf").html('<div class="alert alert-info">' + str + "</div>");

    this.httpService.get(generateLink).subscribe(
      data => {
        this.loadData = data as any[];

        // Get all data
        for (let i = 0; i < this.loadData.length; i++) {
          // console.log("True Loop " + i + ": " + this.loadData[i]["date"]);

          let localSubLink = generateSubLink + this.loadData[i]["date"] + ".json";
          this.httpService.get(localSubLink).subscribe(
            data => {
              console.log("Into AJAX  " + i + ": " + localSubLink);
              this.expandedData[i] = data as any[];
              let count = 0;
              while (count < 7) {
                this.dataDetails = this.expandedData[i][count]["working"] as any[];
                for (let i = 0; i < this.dataDetails.length; i++) {
                  if (this.totalProjectHrs[i] == null) {
                    this.totalProjectHrs[i] = 0;
                  }
                  this.totalProjectHrs[i] += this.dataDetails[i]["hrs"];
                }
                count++;
              }
              console.log("   |-- " + i);
            },
            (err: HttpErrorResponse) => {
              $.notify(err);
            }
          );
        }
        // End of Get all data
      },
      (err: HttpErrorResponse) => {
        $("#reportsOf").html(
          '<div class="alert alert-danger"><strong>No data!</strong> No matched data found for this given values... </div>'
        );
      }
    );
  }

  expandedData: any[];
  expandedDataView: string;
  dataDetails: any[];
  totalProjectHrs: Array<number>;
  expand_week_view(id, file) {
    this.expandedDataView = id;
    this.expandedData = null;
    // this.dataDetails = null;
    this.totalProjectHrs = [];

    if ($("#btn_week_" + id).val() == 0) {
      $("#btn_week_" + id).val(1);

      $("#btn_week_" + id).removeClass("btn-success");
      $("#btn_week_" + id).addClass("btn-warning");
      $("#span_week_" + id).removeClass("fa fa-plus-circle");
      $("#span_week_" + id).addClass("fa fa-minus-square-o");

      // Get All Expanded Data
      let localSubLink = generateSubLink + file + ".json";
      this.httpService.get(localSubLink).subscribe(
        data => {
          this.expandedData = data as any[];
          var count = 0;

          while (count < 7) {
            this.dataDetails = this.expandedData[count]["working"] as any[];
            for (let i = 0; i < this.dataDetails.length; i++) {
              if (this.totalProjectHrs[i] == null) {
                this.totalProjectHrs[i] = 0;
              }
              this.totalProjectHrs[i] += this.dataDetails[i]["hrs"];
            }
            count++;
          }
        },
        (err: HttpErrorResponse) => {
          $.notify(err);
        }
      );

    } else {
      $("#btn_week_" + id).val(0);
      $("#btn_week_" + id).removeClass("btn-warning");
      $("#btn_week_" + id).addClass("btn-success");
      $("#span_week_" + id).removeClass("fa fa-minus-square-o");
      $("#span_week_" + id).addClass("fa fa-plus-circle");

      $("#detailed_week_view_" + id).html("");
    }
  }

  projectName: any[];
  addProject() {
    var project_no = $("#btnAddProject").val();
    project_no++;

    if (project_no >= 4) {
      $("#btnAddProject").attr("disabled", "disabled");
    }

    this.httpService.get("../../assets/data/ProjectNames.json").subscribe(
      data => {
        this.projectName = data as any[];

        var pData = '<div id="project_' + project_no + '" class="addProjectWorking col-md-2">' +
          '<select class="form-control" id = "projectName_' + project_no + '" name = "projectName_' + project_no + '" onchange = "updateProjectName(' + project_no + ')" >' +
          '<option selected value="0"> Select </option>';

        for (let i = 0; i < this.projectName.length; i++) {
          pData += '<option value="' + this.projectName[i]["id"] + '">' + this.projectName[i]["name"] + '</option>';
        }

        pData += '</select>' +
          '<button onclick="delete_project(' + project_no + ')" type="button" class="close">&times;</button>' +
          '</div>';
        $("#add_project").append(pData);

        $("#btnAddProject").val(project_no);


        for (var i = 1; i <= 7; i++) {
          var projectDetails = '<div class="project_details" id="project_details_' + project_no + '_' + i + '">' +
            '<div class="col-md-3 working-details">' +
            '<input type="hidden" name="ProjectName_' + project_no + '"">' +
            '<input class="form-control" type="text" name="hrs_' + project_no + '_' + i + '" id="hrs_' + project_no + '_' + i + '" placeholder="Hrs.">' +
            '<span class="fa fa-pencil-square fa-lg" onclick="openComment(' + project_no + ',' + i + ')"></span>' +
            '</div>' +
            '</div>';

          $("#working_" + i).append(projectDetails);
        }
      },
      (err: HttpErrorResponse) => {
        $.notify(err);
      }
    );
  }

  saveData(id) {
    var data = $("#form_" + id).serializeArray();
  }

  detailed_view(id) {
    var checkBox = document.getElementById(
      "data_expanded_view_" + id
    )! as HTMLInputElement;
    if (checkBox.checked == true) {
      $(".detailed_view" + id).show();
    } else {
      $(".detailed_view" + id).hide();
    }
  }
}
